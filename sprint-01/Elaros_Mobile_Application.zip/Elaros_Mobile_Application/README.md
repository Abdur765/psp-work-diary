# elaros_mobile_app

Proffesional Software Projects Elaros Wellbeing app. Written in Flutter.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Learn Flutter](https://docs.flutter.dev/get-started/learn-flutter)
- [Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Flutter learning resources](https://docs.flutter.dev/reference/learning-resources)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

# Style Guide

- Use the [Dart Style Guide](https://dart.dev/guides/language/effective-dart/style) as a guideline.
- Use the [Flutter MVVM architecture](https://docs.flutter.dev/app-architecture/guide) as a guideline.

# Libraries/Frameworks Documentation

- [Flutter](https://docs.flutter.dev/development/ui/widgets-intro)
- [Provider](https://pub.dev/packages/provider)

# CLI Documentation

`bash flutter devices` - list all connected devices
`bash flutter run` - run the app on the connected device
